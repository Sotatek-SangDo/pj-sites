<?php
/*
Plugin Name: Better Disqus Comments
Plugin URI: http://betterstudio.com
Description: Take advantage of powerful and unique features by integrating Disqus comments on your website instead of the standard WordPress commenting system.
Version: 1.0.0
Author: BetterStudio
Author URI: http://betterstudio.com
License: GPL2
*/


/**
 * Better_Disqus_Comments class wrapper for make changes safe in future
 *
 * @return Better_Disqus_Comments
 */
function Better_Disqus_Comments(){
    return Better_Disqus_Comments::self();
}


// Initialize Better Disqus Comments
Better_Disqus_Comments();


/**
 * Class Better_Disqus_Comments
 */
class Better_Disqus_Comments{


    /**
     * Contains Better_Disqus_Comments version number that used for assets for preventing cache mechanism
     *
     * @var string
     */
    private static $version = '1.0.0';


    /**
     * Contains plugin option panel ID
     *
     * @var string
     */
    private static $panel_id = 'better_disqus_comments';


    /**
     * Inner array of instances
     *
     * @var array
     */
    protected static $instances = array();


    function __construct(){

        // Admin panel options
        add_filter( 'better-framework/panel/options' , array( $this , 'setup_option_panel' ) );

        // Initialize
        add_action( 'better-framework/after_setup', array( $this, 'bf_init' ) );

    }


    /**
     * Used for accessing plugin directory URL
     *
     * @param string $address
     *
     * @return string
     */
    public static function dir_url( $address = '' ){

        return plugin_dir_url( __FILE__ ) . $address;

    }


    /**
     * Used for accessing plugin directory path
     *
     * @param string $address
     *
     * @return string
     */
    public static function dir_path( $address = '' ){

        return plugin_dir_path( __FILE__ ) . $address;

    }


    /**
     * Returns plugin current Version
     *
     * @return string
     */
    public static function get_version(){

        return self::$version ;

    }


    /**
     * Build the required object instance
     *
     * @param   string    $object
     * @param   bool      $fresh
     * @param   bool      $just_include
     *
     * @return  Better_Disqus_Comments|null
     */
    public static function factory( $object = 'self', $fresh = false , $just_include = false ){

        if( isset( self::$instances[$object] ) && ! $fresh ){
            return self::$instances[$object];
        }

        switch( $object ){

            /**
             * Main Better_Disqus_Comments Class
             */
            case 'self':
                $class = 'Better_Disqus_Comments';
                break;

            default:
                return null;
        }


        // Just prepare/includes files
        if( $just_include )
            return;

        // don't cache fresh objects
        if( $fresh ){
            return new $class;
        }

        self::$instances[$object] = new $class;

        return self::$instances[$object];
    }


    /**
     * Used for accessing alive instance of Better_Disqus_Comments
     *
     * @since 1.0
     *
     * @return Better_Disqus_Comments
     */
    public static function self(){

        return self::factory();

    }


    /**
     * Used for retrieving options simply and safely for next versions
     *
     * @param $option_key
     *
     * @return mixed|null
     */
    public static function get_option( $option_key ){

        return bf_get_option( $option_key, self::$panel_id );

    }


    /**
     * Callback: Adds included BetterFramework to BF loader
     *
     * Filter: better-framework/loader
     *
     * @param $frameworks
     *
     * @return array
     */
    function better_framework_loader( $frameworks ){

        $frameworks[] = array(
            'version'   =>  '2.0.0',
            'path'      =>  $this->dir_path( 'includes/libs/better-framework/' ),
            'uri'       =>  $this->dir_url('includes/libs/better-framework/' ),
        );

        return $frameworks;

    }


    /**
     *  Init the plugin
     */
    function bf_init(){

        load_plugin_textdomain( 'better-studio', false, 'better-disqus-comments/languages' );

        if( is_admin() ){
            if( $this->get_option( 'shortname' ) && function_exists( 'Better_Facebook_Comments' ) && Better_Facebook_Comments()->get_option( 'app_id' ) ){
                BF()->admin_notices()->add_notice(array(
                    'id'     => 'facebook-and-disqus-same-time',
                    'msg'    => __( 'You activated both <strong>Facebook Comments</strong> and <strong>Disqus Comments</strong>. Please ensure that only one comment plugin is active at a time.', 'better-studio' )
                ));
            }else{
                BF()->admin_notices()->remove_notice( 'facebook-and-disqus-same-time' );
            }
        }

        if( $this->get_option( 'shortname' ) != '' && ! is_admin() ){

            // Change default template
            add_filter( 'comments_template', array( $this, 'custom_comments_template' ) );

            // Update commetns link
            add_filter( 'better-studio/theme/meta/comments/link', array( $this, 'better_studio_themes_comment_link' ), 10, 2 );

            // Clear themes comments count text in meta
            add_filter( 'better-studio/themes/meta/comments/text', array( $this, 'better_studio_themes_comment_text' ) );

            // Add disqus count js
            BF()->assets_manager()->add_js( " var disqus_shortname = '" . $this->get_option( 'shortname' ) . "';
            (function () {
                var s = document.createElement('script'); s.async = true;
                s.type = 'text/javascript';
                s.src = '//' + disqus_shortname + '.disqus.com/count.js';
                (document.getElementsByTagName('HEAD')[0] || document.getElementsByTagName('BODY')[0]).appendChild(s);
            }());" );

            add_action( 'wp_footer', array( $this, 'wp_footer' ) );

        }
    }


    /**
     *  Init the plugin
     */
    function wp_footer(){

        // Add Disqus main js file
        if( is_singular() && comments_open() ){

            BF()->assets_manager()->add_js( "var disqus_shortname = '" . $this->get_option( 'shortname' ) . "';
                (function() {
                    var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
                    dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
                    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
                })();" );

        }

    }


    /**
     * Callback: Setup setting panel
     *
     * Filter: better-framework/panel/options
     *
     * @param $options
     *
     * @return array
     */
    function setup_option_panel( $options ){

        $field['shortname'] = array(
            'name'          =>  __( 'Site Shortname', 'better-studio' ),
            'id'            =>  'shortname',
            'desc'          =>  __( 'Enter the shortname for your website. This is generated in your Disqus account.', 'better-studio' ),
            'type'          =>  'text',
            'std'           =>  '',
        );


        // Language  name for smart admin texts
        $lang = bf_get_current_lang_raw();
        if( $lang != 'none' ){
            $lang = bf_get_language_name( $lang );
        }else{
            $lang = '';
        }


        $options[self::$panel_id] = array(
            'config' => array(
                'parent'                =>  'better-studio',
                'slug' 			        =>  'better-studio/better-disqus-comments',
                'name'                  =>  __( 'Better Disqus Comments', 'better-studio' ),
                'page_title'            =>  __( 'Better Disqus Comments', 'better-studio' ),
                'menu_title'            =>  __( 'Disqus Comments', 'better-studio' ),
                'capability'            =>  'manage_options',
                'icon_url'              =>  null,
                'position'              =>  80.07,
                'exclude_from_export'   =>  false,
            ),
            'texts'         =>  array(

                'panel-desc-lang'       =>  '<p>' . __( '%s Language Options.', 'better-studio' ) . '</p>',
                'panel-desc-lang-all'   =>  '<p>' . __( 'All Languages Options.', 'better-studio' ) . '</p>',

                'reset-button'      => ! empty( $lang ) ? sprintf( __( 'Reset %s Options', 'better-studio' ), $lang ) : __( 'Reset Options', 'better-studio' ),
                'reset-button-all'  => __( 'Reset All Options', 'better-studio' ),

                'reset-confirm'     =>  ! empty( $lang ) ? sprintf( __( 'Are you sure to reset %s options?', 'better-studio' ), $lang ) : __( 'Are you sure to reset options?', 'better-studio' ),
                'reset-confirm-all' => __( 'Are you sure to reset all options?', 'better-studio' ),

                'save-button'       =>  ! empty( $lang ) ? sprintf( __( 'Save %s Options', 'better-studio' ), $lang ) : __( 'Save Options', 'better-studio' ),
                'save-button-all'   =>  __( 'Save All Options', 'better-studio' ),

                'save-confirm-all'  =>  __( 'Are you sure to save all options? this will override specified options per languages', 'better-studio' )

            ),
            'panel-name'        => _x( 'Better Disqus Comments', 'Panel title', 'better-studio' ),
            'panel-desc'        =>  '<p>' . __( 'Take advantage of integrating Disqus comments on your website.', 'better-studio' ) . '</p>',
            'fields'            => $field
        );

        return $options;
    }


    /**
     * Finds appropriate template file and return path
     * This make option to change template in themes
     *
     * @return string
     */
    function get_template(){

        // Use theme specified template for search page
        if( file_exists( get_template_directory() . '/better-disqus-comments.php' ) ){
            return get_template_directory() . '/better-disqus-comments.php';
        }

        return $this->dir_path( 'templates/better-disqus-comments.php' );

    }


    /**
     * Changes WP comments template with diqus template
     *
     * @return string
     */
    function custom_comments_template(){

        return $this->get_template();

    }


    /**
     * Callback: Used to clear themes meta text to better style in front-end
     *
     * Filter: better-studio/themes/meta/comments/text
     *
     * @param $text
     * @return string
     */
    function better_studio_themes_comment_text( $text ) {

        return '';

    }


    /**
     * Callback: Used to change themes meta link to support disqus count
     *
     * Filter: better-studio/themes/meta/comments/link
     *
     * @param $link string
     *
     * @return string
     */
    function better_studio_themes_comment_link( $link ) {

        return get_permalink() . '#disqus_thread';

    }

}
