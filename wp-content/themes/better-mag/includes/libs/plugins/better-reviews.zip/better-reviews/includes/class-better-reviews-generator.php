<?php

/**
 * Generate Reviews Preview Codes
 */
class Better_Reviews_Generator {


    function __construct(){

        add_filter( 'the_content', array( $this, 'bf_main_content' ) );

    }


    /**
     * Filter Callback: Main Content off page and posts
     *
     * @param $content
     * @return string
     */
    public function bf_main_content( $content ){

        if( $this->is_review_enabled() ){

            $atts = $this->prepare_atts( array() );

            if( $atts['position'] && $atts['position'] != 'none' ){

                if( $atts['position'] == 'top' ){

                    $content = $this->generate_block( $atts ) . $content;

                }elseif( $atts['position'] == 'bottom' ){

                    $content = $content . $this->generate_block( $atts );

                }
            }

        }

        return $content ;

    }


    /**
     * Used for preparing review atts
     *
     * @param $atts
     * @return array
     */
    public function prepare_atts( $atts = array() ){

        return array_merge(

            array(
                'type'              => Better_Reviews()->get_meta( '_bs_review_rating_type' ),
                'heading'           => Better_Reviews()->get_meta( '_bs_review_heading'),
                'verdict'           => Better_Reviews()->get_meta( '_bs_review_verdict' ),
                'summary'           => Better_Reviews()->get_meta( '_bs_review_verdict_summary' ),
                'criteria'          => Better_Reviews()->get_meta( '_bs_review_criteria' ),
                'position'          => Better_Reviews()->get_meta( '_bs_review_pos' ),
                'extra_desc'        => Better_Reviews()->get_meta( '_bs_review_extra_desc' ),
            ),

            $atts

        );

    }


    /**
     * Used for preparing review atts
     *
     * @param $atts
     * @return array
     */
    public function prepare_rate_atts( $atts = array() ){

        return array_merge(

            array(
                'type'              => Better_Reviews()->get_meta( '_bs_review_rating_type' ),
                'criteria'          => Better_Reviews()->get_meta( '_bs_review_criteria' ),
            ),

            $atts

        );

    }



    /**
     * Used for checking state of review
     *
     * @return string
     */
    public function is_review_enabled(){

        return Better_Reviews()->get_meta( '_bs_review_enabled' );

    }


    /**
     * Generates big block
     *
     * @param $atts
     * @return string
     */
    public function generate_block( $atts ){

        // Review is not enable
        if( ! $this->is_review_enabled() ){
            return '';
        }

        $atts = $this->prepare_atts( $atts );

        $overall_rate = $this->calculate_overall_rate( $atts );


        ob_start();

            ?>
        <section class=" betterstudio-review type-<?php echo $atts['type']; ?>" <?php if( Better_Reviews()->get_option( 'add_rich_snippet' ) ){ ?> itemscope="" itemtype="http://schema.org/Review"<?php }?>>

        <?php if( Better_Reviews()->get_option( 'add_rich_snippet' ) ){ ?>
            <div style="display:none" itemprop="reviewBody"><?php echo strip_tags( $this->excerpt( 24 , null, false ) ); ?></div>
            <div style="display:none" class="name entry-title" itemprop="name"><?php the_title(); ?></div>
            <div style="display:none" class="entry-title" itemprop="itemReviewed" itemscope="" itemtype="http://schema.org/Thing"><span itemprop="name"><?php the_title(); ?></span></div>
            <meta itemprop="datePublished" content="<?php the_time( 'Y-m-d' ); ?>">
            <div style="display:none" class="vcard author" itemprop="author" itemscope="" itemtype="http://schema.org/Person"><strong class="fn" itemprop="name"><?php the_author(); ?></strong></div>

            <?php
            $u_time = get_the_time( 'U' );
            $u_modified_time = get_the_modified_time( 'U' );
            if( $u_modified_time >= $u_time + 86400 ){ ?>
                <div style="display:none" class="updated"><?php the_modified_time('Y-m-d') ?></div><?php
            } ?>
        <?php }?>

        <div class="verdict clearfix" <?php if( Better_Reviews()->get_option( 'add_rich_snippet' ) ){ ?>itemprop="reviewRating" itemscope="" itemtype="http://schema.org/Rating"<?php }?>>
            <?php if( Better_Reviews()->get_option( 'add_rich_snippet' ) ){ ?>
                <meta itemprop="worstRating" content="1">
                <meta itemprop="bestRating" content="100">
                <span class="rating points" style="display:none"><span class="rating points" itemprop="ratingValue"><?php echo $overall_rate; ?></span></span>
            <?php }?>
            <div class="overall">
                        <span class="rate"><?php

                            if( $atts['type'] == 'points' ){
                                echo round( $overall_rate / 10 ,1 );
                            }
                            else{
                                echo $overall_rate;
                            }


                            if( $atts['type'] != 'points' ){
                                echo '<span class="percentage">%</span>';
                            }

                            ?></span>
                    <?php

                    echo $this->get_rating( $overall_rate, $atts['type'] );

                    ?>
                    <span class="verdict-title"><?php echo $atts['verdict']; ?></span>
                </div>
                <?php  ?>
                <div class="the-content verdict-summary"  <?php if( Better_Reviews()->get_option( 'add_rich_snippet' ) ){ ?> itemprop="description"<?php }?>><?php
                    if( ! empty( $atts['heading'] ) )
                        echo '<h4 class="page-heading uppercase"><span class="h-title">' . $atts['heading'] . '</span></h4>';

                    echo wpautop( do_shortcode( $atts['summary'] ) ); ?>
                </div>
            </div>
            <ul class="criteria-list"><?php

                foreach( $atts['criteria'] as $criteria ){

                    ?><li class="clearfix">
                    <div class="criterion">
                        <span class="title"><?php echo ! empty( $criteria['label'] ) ? $criteria['label'] : __( 'Criteria', 'better-studio' ); ?></span>
                        <?php if( $atts['type'] !='stars' ){ ?>
                            <span class="rate"><?php echo $atts['type'] !='points' ?  round( $criteria['rate'] * 10 ) . '%' : $criteria['rate']; ?></span>
                        <?php } ?>
                    </div>
                    <?php
                    if( $atts['type'] != 'points' ){
                        echo $this->get_rating( $criteria['rate'] * 10, $atts['type'] );
                    }else{
                        echo $this->get_rating( $criteria['rate'] * 10, $atts['type'] );
                    }
                    ?>
                    </li>
                <?php
                }

                ?>
            </ul>
            <?php if( ! empty( $atts['extra_desc'] ) ){ ?>
            <div class="review-description"><?php echo wpautop( do_shortcode( $atts['extra_desc'] ) ); ?></div>
            <?php } ?>
        </section><?php

        return ob_get_clean();
    }


    /**
     * Calculates overall rate
     *
     * @param $atts
     * @return float
     */
    public function calculate_overall_rate( $atts = null ){

        if( is_null( $atts ) ){
            $atts = $this->prepare_atts( array() );
        }

        $total = 0;

        foreach( $atts['criteria'] as $criteria ){
            $total += floatval( $criteria['rate'] ) * 10;
        }

        if( $atts['type'] == 'points' ){
            return round( $total / count( $atts['criteria'] ), 1 );
        }else{
            return round( $total / count( $atts['criteria'] ) );
        }

    }


    /**
     * Used for retiring generated bars
     *
     * @param $rate
     * @param string $type
     * @param bool $show_rate
     * @return string
     */
    public function get_rating( $rate, $type = 'stars', $show_rate = false ){


        if( $show_rate ){
            if( $type == 'points' ){
                $show_rate = '<span class="rate-number">' . round( $rate / 10, 1 ) . '</span>';
            }else{
                $show_rate = '<span class="rate-number">' . $rate . '%</span>';
            }
        }else{
            $show_rate = '';
        }

        if( $type == 'points' || $type == 'percentage' ){
            $type = 'bar';
        }


        return '<div class="rating-' . $type . '"><span style="width: ' . $rate . '%;"></span>' . $show_rate . '</div>';

    }


    /**
     * Deprecated!
     *
     * Custom excerpt
     *
     * @param  integer $length
     * @param  string|null $text
     * @param bool $echo
     *
     * @return string
     */
     function excerpt( $length = 24, $text = null, $echo = true ){

        // If text not defined get excerpt
        if( ! $text ){

            // have a manual excerpt?
            if( has_excerpt( get_the_ID() ) ){

                if( $echo ){
                    echo apply_filters( 'the_excerpt', get_the_excerpt() );
                    return;
                }else
                    return apply_filters( 'the_excerpt', get_the_excerpt() );

            }else{

                $text = get_the_content( '' );

            }

        }

        $text = strip_shortcodes( $text );
        $text = str_replace( ']]>', ']]&gt;', $text );

        // get plaintext excerpt trimmed to right length
        $excerpt = wp_trim_words( $text, $length, '&hellip;' );

        // fix extra spaces
        $excerpt = trim( str_replace('&nbsp;', ' ', $excerpt ) );


        if( $echo )
            echo $excerpt;
        else
            return $excerpt;
    }

}