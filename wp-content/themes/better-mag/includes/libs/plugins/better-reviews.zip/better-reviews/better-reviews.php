<?php
/*
Plugin Name: Better Reviews
Plugin URI: http://betterstudio.com
Description: BetterStudio Reviews Plugin
Version: 1.0.3
Author: BetterStudio
Author URI: http://betterstudio.com
License: GPL2
*/


/**
 * Better_Reviews class wrapper
 *
 * @return Better_Reviews
 */
function Better_Reviews(){

    return Better_Reviews::self();

}

// Fire up Better Reviews
Better_Reviews();

/**
 * Better Reviews Functionality
 */
class Better_Reviews{


    /**
     * Contains BR version number that used for assets for preventing cache mechanism
     *
     * @var string
     */
    private static $version = '1.0.2';


    /**
     * Contains BR option panel id
     *
     * @var string
     */
    private static $panel_id = 'better_reviews_options';


    /**
     * Inner array of instances
     *
     * @var array
     */
    protected static $instances = array();


    function __construct(){

        // Generator Class
        self::generator();

        // Register included BF to loader
        add_filter( 'better-framework/loader', array( $this, 'better_framework_loader' ) );

        // Admin panel options
        add_filter( 'better-framework/panel/options' , array( $this , 'setup_option_panel' ) );

        // Used for adding review metabox
        add_filter( 'better-framework/metabox/options' , array( $this , 'register_better_reviews_metabox'), 20 );

        // Used for adding shortcode
        add_action( 'init', array( $this, 'wp_init' ) );

        add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' )  );

        add_filter( 'betterstudio-editor-shortcodes', array( $this, 'register_shortcode_to_editor' ) );

        // Includes BF loader if not included before
        require_once self::dir_path( 'includes/libs/better-framework/init.php' );

    }


    /**
     * Used for accessing plugin directory URL
     *
     * @param string $address
     *
     * @return string
     */
    public static function dir_url( $address = '' ){

        return plugin_dir_url( __FILE__ ) . $address;

    }


    /**
     * Used for accessing plugin directory path
     *
     * @param string $address
     *
     * @return string
     */
    public static function dir_path( $address = '' ){

        return plugin_dir_path( __FILE__ ) . $address;

    }


    /**
     * Returns BSC current Version
     *
     * @return string
     */
    public static function get_version(){

        return self::$version ;

    }


    /**
     * Build the required object instance
     *
     * @param string $object
     * @param bool $fresh
     * @param bool $just_include
     *
     * @return null
     */
    public static function factory( $object = 'self', $fresh = false , $just_include = false ){

        if( isset( self::$instances[$object] ) && ! $fresh ){
            return self::$instances[$object];
        }

        switch( $object ){

            /**
             * Main Better_Reviews Class
             */
            case 'self':
                $class = 'Better_Reviews';
                break;

            /**
             * Better_Reviews_Generator Class
             */
            case 'generator':

                require_once self::dir_path() . 'includes/class-better-reviews-generator.php';

                $class = 'Better_Reviews_Generator';
                break;


            default:
                return null;
        }


        // Just prepare/includes files
        if( $just_include )
            return;

        // don't cache fresh objects
        if( $fresh ){
            return new $class;
        }

        self::$instances[$object] = new $class;

        return self::$instances[$object];
    }


    /**
     * Used for accessing alive instance of Better_Reviews
     *
     * @since 1.0
     *
     * @return Better_Reviews
     */
    public static function self(){

        return self::factory();

    }


    /**
     * Used for retrieving instance of generator
     *
     * @param $fresh
     *
     * @return Better_Reviews_Generator
     */
    public static function generator( $fresh = false ){

        return self::factory( 'generator', $fresh );
    }


    /**
     * Used for retrieving options simply and safely for next versions
     *
     * @param $option_key
     *
     * @return mixed|null
     */
    public static function get_option( $option_key ){

        return bf_get_option( $option_key, self::$panel_id );

    }


    /**
     * Used for retrieving post meta
     *
     * @param null $key
     * @param bool $default
     * @param null $post_id
     *
     * @return string
     */
    public static function get_meta( $key = null, $default = true, $post_id = null ){

        if( is_null( $post_id ) ){
            global $post;
            $post_id = $post->ID;
        }

        return bf_get_post_meta( $key, $post_id );

    }


    /**
     * Adds included BetterFramework to loader
     *
     * @param $frameworks
     * @return array
     */
    function better_framework_loader( $frameworks ){

        $frameworks[] = array(
            'version'   =>  '2.2.0',
            'path'      =>  self::dir_path( 'includes/libs/better-framework/' ),
            'uri'       =>  self::dir_url( 'includes/libs/better-framework/' ),
        );

        return $frameworks;

    }


    /**
     * Action Callback: WordPress Init
     */
    public function wp_init(){

        // Registers shortcode
        add_shortcode( 'better-reviews', array( $this, 'better_reviews_shortcode') );

    }


    /**
     * Action Callback: Registers Admin Style
     */
    public function admin_enqueue_scripts(){

        if( Better_Framework::self()->get_current_page_type() == 'metabox' ){

            wp_enqueue_style( 'better-reviews-admin', self::dir_url( 'css/admin-style.css' ), array(), null );

            wp_enqueue_script( 'better-reviews-admin', self::dir_url( 'js/admin-script.js' ) );

            wp_localize_script(
                'better-reviews-admin',
                'better_reviews_loc',
                apply_filters(
                    'better_reviews_localize_items',
                    array(
                        'overall_rating'  => __( 'Overall Rating', 'better-studio'),
                    )
                )
            );

        }

    }


    /**
     * Filter Callback: Registers shortcode to BetterStudio Editor Shortcodes Plugin
     *
     * @param $shortcodes
     *
     * @return mixed
     */
    public function register_shortcode_to_editor( $shortcodes ){

        $_shortcodes = array();

        $_shortcodes['sep' . time()] = array(
            'type'          =>  'separator',
        );

        $_shortcodes['reviews'] = array(
            'type'          =>  'menu',
            'label'         =>  __( 'Better Reviews', 'better-studio' ),
            'register'      =>  false,
            'items'         =>  array(

                'review-stars'  => array(
                    'type'          =>  'button',
                    'label'         =>  __( 'Review Stars', 'better-studio' ),
                    'register'      =>  false,
                    'content'       =>  '[better-reviews type="stars"]',
                ),

                'review-percentage' => array(
                    'type'          =>  'button',
                    'label'         =>  __( 'Review Percentage', 'better-studio' ),
                    'register'      =>  false,
                    'content'       =>  '[better-reviews type="percentage"]',
                ),

                'review-points' => array(
                    'type'          =>  'button',
                    'label'         =>  __( 'Review Points', 'better-studio' ),
                    'register'      =>  false,
                    'content'       =>  '[better-reviews type="points"]',
                ),

            )
        );

        return $shortcodes + $_shortcodes;
    }


    /**
     * Shortcode: Review Shortcode Handler
     *
     * @param $atts
     * @param null $content
     *
     * @return string
     */
    public function better_reviews_shortcode( $atts, $content = null ){

        return self::generator()->generate_block( $atts );

    }


    /**
     * Registers review admin fields with BetterFramework
     *
     * @param $options
     *
     * @return mixed
     */
    public function register_better_reviews_metabox( $options ){

        $fields = array();

        /**
         * => General Options
         */
        $fields['_general_options'] = array(
            'name'          =>  __( 'General', 'better-studio' ),
            'id'            =>  '_general_options',
            'type'          =>  'tab',
            'icon'          =>  'bsai-global',
        );
        $fields['_bs_review_enabled'] = array(
            'name'          =>  __( 'Enable Review', 'better-studio' ),
            'id'            =>  '_bs_review_enabled',
            'std'           =>  '0' ,
            'type'          =>  'switch',
            'on-label'      =>  __( 'Enable', 'better-studio' ),
            'off-label'     =>  __( 'Disable', 'better-studio' ),
            'desc'          =>  __( 'Enabling this will adds review box to post', 'better-studio' ),
        );

        /**
         * => Style Options
         */
        $fields['_style_options'] = array(
            'name'          =>  __( 'Style', 'better-studio' ),
            'id'            =>  '_style_options',
            'type'          =>  'tab',
            'icon'          =>  'bsai-paint',
        );
        $fields['_bs_review_pos'] = array(
            'name'          =>  __( 'Review Box Position', 'better-studio' ),
            'id'            =>  '_bs_review_pos',
            'std'           =>  'top',
            'type'          =>  'select',
            'desc'          =>  __( 'Chose position of review box on page. <br> For showing review box between post texts you should chose "Do Not Display" and use "<strong>[better-review]</strong>" shrotcode.', 'better-studio' ),
            'options'       =>  array(
                'none'          =>  __( 'Do Not Display', 'better-studio' ),
                'top'           =>  __( 'Top', 'better-studio' ),
                'bottom'        =>  __( 'Bottom', 'better-studio' ),
            )
        );
        $fields['_bs_review_rating_type'] = array(
            'name'          =>  __( 'Rating Style', 'better-studio' ),
            'desc'          =>  __( 'Chose style of review', 'better-studio' ),
            'id'            =>  '_bs_review_rating_type',
            'std'           =>  'stars',
            'type'          =>  'image_select',
            'section_class' =>  'style-floated-left bordered',
            'options'       =>  array(
                'stars'         =>  array(
                    'img'           =>  self::dir_url() . 'img/review-star.png',
                    'label'         =>  __( 'Stars', 'better-studio' ),
                ),
                'percentage'    =>  array(
                    'img'           =>  self::dir_url() . 'img/review-bar.png',
                    'label'         =>  __( 'Percentage', 'better-studio' ),
                ),
                'points'        =>  array(
                    'img'           =>  self::dir_url() . 'img/review-point.png',
                    'label'         =>  __( 'Points', 'better-studio' ),
                )
            )
        );
        $fields[] = array(
            'name'      =>  __( 'Review Box Padding', 'better-studio' ),
            'type'      => 'group',
            'state'     => 'close',
        );
            $fields['_bs_review_box_padding_top'] = array(
                'name'          =>  __( 'Review Box Top Padding', 'better-studio' ),
                'id'            =>  '_bs_review_box_padding_top',
                'suffix'        =>  __( 'Pixel', 'better-studio' ),
                'desc'          =>  __( 'In pixels without px, ex: 20. <br>Leave empty for default value.', 'better-studio' ),
                'type'          =>  'text',
                'std'           =>  '',
                'css-echo-default'  => false,
                'css'           =>  array(
                    array(
                        'selector'  => array(
                            '.betterstudio-review'
                        ),
                        'prop'      => array( 'padding-top' => '%%value%%px' ),
                    )
                ),
            );
            $fields['_bs_review_box_padding_bottom'] = array(
                'name'          =>  __( 'Review Box Bottom Padding', 'better-studio' ),
                'id'            =>  '_bs_review_box_padding_bottom',
                'suffix'        =>  __( 'Pixel', 'better-studio' ),
                'desc'          =>  __( 'In pixels without px, ex: 20. <br>Leave empty for default value.', 'better-studio' ),
                'type'          =>  'text',
                'std'           =>  '',
                'css-echo-default'  => false,
                'css'           =>  array(
                    array(
                        'selector'  => array(
                            '.betterstudio-review'
                        ),
                        'prop'      => array( 'padding-bottom' => '%%value%%px' ),
                    )
                ),
            );
            $fields['_bs_review_box_padding_left'] = array(
                'name'          =>  __( 'Review Box Left Padding', 'better-studio' ),
                'id'            =>  '_bs_review_box_padding_left',
                'suffix'        =>  __( 'Pixel', 'better-studio' ),
                'desc'          =>  __( 'In pixels without px, ex: 20. <br>Leave empty for default value.', 'better-studio' ),
                'type'          =>  'text',
                'std'           =>  '',
                'css-echo-default'  => false,
                'css'           =>  array(
                    array(
                        'selector'  => array(
                            '.betterstudio-review'
                        ),
                        'prop'      => array( 'padding-left' => '%%value%%px' ),
                    )
                ),
            );
            $fields['_bs_review_box_padding_right'] = array(
                'name'          =>  __( 'Review Box Right Padding', 'better-studio' ),
                'suffix'        =>  __( 'Pixel', 'better-studio' ),
                'id'            =>  '_bs_review_box_padding_right',
                'desc'          =>  __( 'In pixels without px, ex: 20. <br>Leave empty for default value.', 'better-studio' ),
                'type'          =>  'text',
                'std'           =>  '',
                'css-echo-default'  => false,
                'css'           =>  array(
                    array(
                        'selector'  => array(
                            '.betterstudio-review'
                        ),
                        'prop'      => array( 'padding-right' => '%%value%%px' ),
                    )
                ),
            );


        /**
         * => Verdict Options
         */
        $fields['_verdict_options'] = array(
            'name'          =>  __( 'Verdict', 'better-studio' ),
            'id'            =>  '_verdict_options',
            'type'          =>  'tab',
            'icon'          =>  'bsai-verdict',
        );
            $fields['_bs_review_heading'] = array(
                'name'          =>  __( 'Heading', 'better-studio' ),
                'id'            =>  '_bs_review_heading',
                'std'           =>  '' ,
                'type'          =>  'text',
                'desc'          =>  __( 'Optional title for review box', 'better-studio' ),
            );
            $fields['_bs_review_verdict'] = array(
                'name'          =>  __( 'Verdict', 'better-studio' ),
                'id'            =>  '_bs_review_verdict',
                'std'           =>  __( 'Awesome', 'better-studio' ),
                'type'          =>  'text',
                'desc'          =>  __( '1 or 2 word for overall verdict. ex: Awesome', 'better-studio' ),
            );
            $fields['_bs_review_verdict_summary'] = array(
                'name'          =>  __( 'Verdict Description - Top', 'better-studio' ),
                'desc'          =>  __( 'Verdict description that will be shown on top of criteria', 'better-studio' ),
                'id'            =>  '_bs_review_verdict_summary',
                'std'           =>  '' ,
                'type'          =>  'textarea',
            );
            $fields['_bs_review_extra_desc'] = array(
                'name'          =>  __( 'Verdict Description - Bottom', 'better-studio' ),
                'desc'          =>  __( 'Verdict description that will be shown under criteria', 'better-studio' ),
                'id'            =>  '_bs_review_extra_desc',
                'std'           =>  '' ,
                'type'          =>  'textarea',
            );


        /**
         * => Criteria Options
         */
        $fields['_criteria_options'] = array(
            'name'          =>  __( 'Criteria', 'better-studio' ),
            'id'            =>  '_criteria_options',
            'type'          =>  'tab',
            'icon'          =>  'bsai-list-bullet',
        );
        $fields['_bs_review_criteria'] = array(
            'name'          =>  __( 'Criteria', 'better-studio' ),
            'id'            =>  '_bs_review_criteria',
            'type'          =>  'repeater',
            'save-std'      =>  true,
            'std'           =>  array(),
            'add_label'     =>  '<i class="fa fa-plus"></i> ' . __( 'Add Criterion', 'better-studio' ),
            'delete_label'  =>  __( 'Delete Criterion', 'better-studio' ),
            'item_title'    =>  __( 'Criterion', 'better-studio' ),
            'section_class' => 'full-with-both',
            'default'       => array(
                array(
                    'label' => __( 'Design', 'better-studio' ),
                    'rate'  => '8',
                )
            ),
            'options'       =>  array(
                'label' => array(
                    'name'          =>  __( 'Label', 'better-studio' ),
                    'id'            =>  'label',
                    'std'           =>  '' ,
                    'type'          =>  'text',
                    'section_class' =>  'full-with-both bs-review-field-label',
                    'repeater_item' =>  true
                ),
                'rate' => array(
                    'name'          =>  __( 'Rating / 10', 'better-studio' ),
                    'id'            =>  'rate',
                    'type'          =>  'text',
                    'section_class' =>  'full-with-both bs-review-field-rating',
                    'repeater_item' =>  true,
                ),
            )
        );


        $options['bs_review_metabox'] = array(
            'config'        => array(
                'title'         => __( 'Better Reviews', 'better-studio' ),
                'pages'         => array( 'post' ),
                'context'       => 'normal',
                'prefix'        => false,
                'priority'      => 'normal'
            ),
            'fields'        => $fields
        );

        return $options;
    }


    /**
     * Callback: Setup setting panel
     *
     * Filter: better-framework/panel/options
     *
     * @param $options
     *
     * @return array
     */
    function setup_option_panel( $options ){

        $fields[] = array(
            'name'          =>  __( 'Enable Schema SEO Rich Snippet Review Microdata', 'better-studio' ),
            'id'            =>  'add_rich_snippet',
            'desc'          =>  __( 'Use for adding Microformats to get Rich Snippets showing for your site and increase the CTR from Google.', 'better-studio' ),
            'type'          =>  'switch',
            'std'           =>  true,
            'on-label'  =>  __( 'Enable', 'better-studio' ),
            'off-label' =>  __( 'Disable', 'better-studio' ),
        );

        // Language  name for smart admin texts
        $lang = bf_get_current_lang();
        if( $lang != 'none' ){
            $lang = bf_get_language_name( $lang );
        }else{
            $lang = '';
        }

        $options[self::$panel_id] = array(
            'config' => array(
                'parent'                =>  'better-studio',
                'slug' 			        =>  'better-studio/better-reviews',
                'name'                  =>  __( 'Better Reviews', 'better-studio' ),
                'page_title'            =>  __( 'Better Reviews', 'better-studio' ),
                'menu_title'            =>  __( 'Reviews', 'better-studio' ),
                'capability'            =>  'manage_options',
                'icon_url'              =>  null,
                'position'              =>  80.04,
                'exclude_from_export'   =>  false,
            ),
            'texts'         =>  array(

                'panel-desc-lang'       =>  '<p>' . __( '%s Language Options.', 'better-studio' ) . '</p>',
                'panel-desc-lang-all'   =>  '<p>' . __( 'All Languages Options.', 'better-studio' ) . '</p>',

                'reset-button'      => ! empty( $lang ) ? sprintf( __( 'Reset %s Options', 'better-studio' ), $lang ) : __( 'Reset Options', 'better-studio' ),
                'reset-button-all'  => __( 'Reset All Options', 'better-studio' ),

                'reset-confirm'     =>  ! empty( $lang ) ? sprintf( __( 'Are you sure to reset %s options?', 'better-studio' ), $lang ) : __( 'Are you sure to reset options?', 'better-studio' ),
                'reset-confirm-all' => __( 'Are you sure to reset all options?', 'better-studio' ),

                'save-button'       =>  ! empty( $lang ) ? sprintf( __( 'Save %s Options', 'better-studio' ), $lang ) : __( 'Save Options', 'better-studio' ),
                'save-button-all'   =>  __( 'Save All Options', 'better-studio' ),

                'save-confirm-all'  =>  __( 'Are you sure to save all options? this will override specified options per languages', 'better-studio' )

            ),
            'panel-name'        => _x( 'Better Reviews', 'Panel title', 'better-studio' ),
            'panel-desc'        =>  '<p>' . __( 'BetterStudio Reviews Plugin', 'better-studio' ) . '</p>',
            'fields'            => $fields
        );

        return $options;
    }

}