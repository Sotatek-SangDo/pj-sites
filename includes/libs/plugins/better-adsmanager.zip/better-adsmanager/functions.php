<?php


/**
 * Used to get array of key->name of campaigns
 *
 * @param int  $count
 * @param bool $empty_label
 *
 * @return array
 */
function bam_get_campaigns_option( $count = 10, $empty_label = FALSE ) {

	$args = array(
		'posts_per_page' => $count,
	);

	if ( $empty_label ) {
		return array( 'none' => __( '-- Select Campaign --', 'better-studio' ) ) + Better_Ads_Manager::get_campaigns( $args );
	} else {
		return Better_Ads_Manager::get_campaigns( $args );
	}

}


/**
 * Used to get array of key->name of banners
 *
 * @param int  $count
 * @param bool $empty_label
 *
 * @return array
 */
function bam_get_banners_option( $count = 10, $empty_label = FALSE ) {

	$args = array(
		'posts_per_page' => $count,
	);

	if ( $empty_label ) {
		return array( 'none' => __( '-- Select Banner --', 'better-studio' ) ) + Better_Ads_Manager::get_banners( $args );
	} else {
		return Better_Ads_Manager::get_campaigns( $args );
	}

}

