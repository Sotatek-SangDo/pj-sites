<?php
/*
Plugin Name: Better Facebook Comments
Plugin URI: http://betterstudio.com
Description: Take advantage of powerful and unique features by integrating Facebook comments on your website instead of the standard WordPress commenting system.
Version: 1.1
Author: BetterStudio
Author URI: http://betterstudio.com
License: GPL2
*/


/**
 * Better_Facebook_Comments class wrapper for make changes safe in future
 *
 * @return Better_Facebook_Comments
 */
function Better_Facebook_Comments(){
    return Better_Facebook_Comments::self();
}


// Initialize Better Facebook Comments
Better_Facebook_Comments();


/**
 * Class Better_Facebook_Comments
 */
class Better_Facebook_Comments{


    /**
     * Contains Better_Facebook_Comments version number that used for assets for preventing cache mechanism
     *
     * @var string
     */
    private static $version = '1.1';


    /**
     * Contains plugin option panel ID
     *
     * @var string
     */
    private static $panel_id = 'better_facebook_comments';


    /**
     * Inner array of instances
     *
     * @var array
     */
    protected static $instances = array();


    function __construct(){

        // Admin panel options
        add_filter( 'better-framework/panel/options' , array( $this , 'setup_option_panel' ) );

        // Initialize
        add_action( 'better-framework/after_setup', array( $this, 'bf_init' ) );

    }


    /**
     * Used for accessing plugin directory URL
     *
     * @param string $address
     *
     * @return string
     */
    public static function dir_url( $address = '' ){

        return plugin_dir_url( __FILE__ ) . $address;

    }


    /**
     * Used for accessing plugin directory path
     *
     * @param string $address
     *
     * @return string
     */
    public static function dir_path( $address = '' ){

        return plugin_dir_path( __FILE__ ) . $address;

    }


    /**
     * Returns plugin current Version
     *
     * @return string
     */
    public static function get_version(){

        return self::$version ;

    }


    /**
     * Build the required object instance
     *
     * @param   string    $object
     * @param   bool      $fresh
     * @param   bool      $just_include
     *
     * @return  Better_Facebook_Comments|null
     */
    public static function factory( $object = 'self', $fresh = false , $just_include = false ){

        if( isset( self::$instances[$object] ) && ! $fresh ){
            return self::$instances[$object];
        }

        switch( $object ){

            /**
             * Main Better_Facebook_Comments Class
             */
            case 'self':
                $class = 'Better_Facebook_Comments';
                break;

            default:
                return null;
        }


        // Just prepare/includes files
        if( $just_include )
            return;

        // don't cache fresh objects
        if( $fresh ){
            return new $class;
        }

        self::$instances[$object] = new $class;

        return self::$instances[$object];
    }


    /**
     * Used for accessing alive instance of Better_Facebook_Comments
     *
     * @since 1.0
     *
     * @return Better_Facebook_Comments
     */
    public static function self(){

        return self::factory();

    }


    /**
     * Used for retrieving options simply and safely for next versions
     *
     * @param $option_key
     *
     * @return mixed|null
     */
    public static function get_option( $option_key ){

        return bf_get_option( $option_key, self::$panel_id );

    }


    /**
     *  Init the plugin
     */
    function bf_init(){

        load_plugin_textdomain( 'better-studio', false, 'better-facebook-comments/languages' );


        if( is_admin() ){
            if( $this->get_option( 'app_id' ) && function_exists( 'Better_Disqus_Comments' ) && Better_Disqus_Comments()->get_option( 'shortname' ) ){
                BF()->admin_notices()->add_notice(array(
                    'id'     => 'facebook-and-disqus-same-time',
                    'msg'    => __( 'You activated both <strong>Facebook Comments</strong> and <strong>Disqus Comments</strong>. Please ensure that only one comment plugin is active at a time.', 'better-studio' )
                ));
            }else{
                BF()->admin_notices()->remove_notice( 'facebook-and-disqus-same-time' );
            }
        }


        if( $this->get_option( 'app_id' ) != '' && ! is_admin() ){

            // Add App ID Meta
            add_action( 'wp_head', array( $this, 'wp_head' ) );

            // Change default template
            add_filter( 'comments_template', array( $this, 'custom_comments_template' ) );

            // Update comments link
            add_filter( 'better-studio/theme/meta/comments/link', array( $this, 'better_studio_themes_comment_link' ), 10, 2 );

            // Clear themes comments count text in meta
            add_filter( 'better-studio/themes/meta/comments/text', array( $this, 'better_studio_themes_comment_text' ) );

            // Enqueue assets
            add_action( 'wp_enqueue_scripts', array( $this, 'wp_enqueue_scripts' ) );

            // Add JS
            add_action( 'wp_footer', array( $this, 'wp_footer' ) );

        }
    }


    /**
     * Callback: Used for adding JS and CSS files to page
     *
     * Action: wp_enqueue_scripts
     */
    function wp_enqueue_scripts(){

        wp_enqueue_script( 'better-facebook-comments', $this->dir_url( 'js/better-facebook-comments.js' ), array( 'jquery' ), $this->get_version(), true );

        wp_localize_script(
            'better-facebook-comments',
            'better_facebook_comments_vars',
            apply_filters(
                'better-facebook-comments/js/global-vars',
                array(
                    'text_0'       => $this->get_option( 'text_no_comment' ),
                    'text_1'       => $this->get_option( 'text_one_comment' ),
                    'text_2'       => $this->get_option( 'text_two_comment' ),
                    'text_more'    => $this->get_option( 'text_comments' ),
                )
            )
        );
    }


    /**
     *  Add FB js and tags
     */
    function wp_footer(){

        // Add Facebook js and tags
        if( is_singular() && comments_open() ){

            ?>
            <div id="fb-root"></div>
            <script>(function(d, s, id) {
                    var js, fjs = d.getElementsByTagName(s)[0];
                    if (d.getElementById(id)) return;
                    js = d.createElement(s); js.id = id;
                    js.src = "//connect.facebook.net/<?php echo $this->get_option( 'locale' ); ?>/sdk.js#xfbml=1&appId=<?php echo $this->get_option( 'app_id' ); ?>&version=v2.0";
                    fjs.parentNode.insertBefore(js, fjs);
                }(document, 'script', 'facebook-jssdk'));
            </script>
            <?php
        }

    }


    /**
     * Callback: Setup setting panel
     *
     * Filter: better-framework/panel/options
     *
     * @param $options
     *
     * @return array
     */
    function setup_option_panel( $options ){

        $fields['app_id'] = array(
            'name'          =>  __( 'App ID', 'better-studio' ),
            'id'            =>  'app_id',
            'desc'          =>  __( 'Enter in your Facebook App ID.', 'better-studio' ),
            'type'          =>  'text',
            'std'           =>  '',
        );
        $fields['numposts'] = array(
            'name'          =>  __( 'Number Posts', 'better-studio' ),
            'id'            =>  'numposts',
            'desc'          =>  __( 'Select the amount of posts per page to display.', 'better-studio' ),
            'type'          =>  'text',
            'std'           =>  '10',
        );
        $fields['order_by'] = array(
            'name'          =>  __( 'Posts Order', 'better-studio' ),
            'id'            =>  'order_by',
            'desc'          =>  __( 'Choose the order for your posts. Selecting "Social" will bring what Facebook deems the highest quality comments to the surface.', 'better-studio' ),
            'type'          =>  'select',
            'std'           =>  'social',
            'options'       =>  array(
                'social'        =>  __( 'Social', 'better-studio' ),
                'time'          =>  __( 'Time', 'better-studio' ),
                'reverse_time'  =>  __( 'Reverse Time', 'better-studio' ),
            )
        );
        $fields['colorscheme'] = array(
            'name'          =>  __( 'Color Scheme', 'better-studio' ),
            'id'            =>  'colorscheme',
            'desc'          =>  __( 'Choose which color scheme you would like for your comments.', 'better-studio' ),
            'type'          =>  'select',
            'std'           =>  'light',
            'options'       =>  array(
                'light' =>  __( 'Light', 'better-studio' ),
                'dark'  =>  __( 'Dark', 'better-studio' ),
            )
        );
        $fields['locale'] = array(
            'name'          =>  __( 'Adjust Language', 'better-studio' ),
            'id'            =>  'locale',
            'desc'          =>  __( 'You can adjust the language of the Comments by changing this option.', 'better-studio' ),
            'type'          =>  'select',
            'std'           =>  'en_US',
            'options'       =>  array()
        );

        // Add locales only in admin to reduce memory usage in front end!
        if( is_admin() ){
            $fields['locale']['options'] = array(
                'af_ZA'  =>  'Afrikaans',
                'ak_GH'  =>  'Akan',
                'am_ET'  =>  'Amharic',
                'ar_AR'  =>  'Arabic',
                'as_IN'  =>  'Assamese',
                'ay_BO'  =>  'Aymara',
                'az_AZ'  =>  'Azerbaijani',
                'be_BY'  =>  'Belarusian',
                'bg_BG'  =>  'Bulgarian',
                'bn_IN'  =>  'Bengali',
                'br_FR'  =>  'Breton',
                'bs_BA'  =>  'Bosnian',
                'ca_ES'  =>  'Catalan',
                'cb_IQ'  =>  'Sorani Kurdish',
                'ck_US'  =>  'Cherokee',
                'co_FR'  =>  'Corsican',
                'cs_CZ'  =>  'Czech',
                'cx_PH'  =>  'Cebuano',
                'cy_GB'  =>  'Welsh',
                'da_DK'  =>  'Danish',
                'de_DE'  =>  'German',
                'el_GR'  =>  'Greek',
                'en_GB'  =>  'English (UK)',
                'en_IN'  =>  'English (India)',
                'en_PI'  =>  'English (Pirate)',
                'en_UD'  =>  'English (Upside Down)',
                'en_US'  =>  'English (US)',
                'eo_EO'  =>  'Esperanto',
                'es_CO'  =>  'Spanish (Colombia)',
                'es_ES'  =>  'Spanish (Spain)',
                'es_LA'  =>  'Spanish',
                'et_EE'  =>  'Estonian',
                'eu_ES'  =>  'Basque',
                'fa_IR'  =>  'Persian',
                'fb_LT'  =>  'Leet Speak',
                'ff_NG'  =>  'Fulah',
                'fi_FI'  =>  'Finnish',
                'fo_FO'  =>  'Faroese',
                'fr_CA'  =>  'French (Canada)',
                'fr_FR'  =>  'French (France)',
                'fy_NL'  =>  'Frisian',
                'ga_IE'  =>  'Irish',
                'gl_ES'  =>  'Galician',
                'gn_PY'  =>  'Guarani',
                'gu_IN'  =>  'Gujarati',
                'gx_GR'  =>  'Classical Greek',
                'ha_NG'  =>  'Hausa',
                'he_IL'  =>  'Hebrew',
                'hi_IN'  =>  'Hindi',
                'hr_HR'  =>  'Croatian',
                'hu_HU'  =>  'Hungarian',
                'hy_AM'  =>  'Armenian',
                'id_ID'  =>  'Indonesian',
                'ig_NG'  =>  'Igbo',
                'is_IS'  =>  'Icelandic',
                'it_IT'  =>  'Italian',
                'ja_JP'  =>  'Japanese',
                'ja_KS'  =>  'Japanese (Kansai)',
                'jv_ID'  =>  'Javanese',
                'ka_GE'  =>  'Georgian',
                'kk_KZ'  =>  'Kazakh',
                'km_KH'  =>  'Khmer',
                'kn_IN'  =>  'Kannada',
                'ko_KR'  =>  'Korean',
                'ku_TR'  =>  'Kurdish (Kurmanji)',
                'la_VA'  =>  'Latin',
                'lg_UG'  =>  'Ganda',
                'li_NL'  =>  'Limburgish',
                'ln_CD'  =>  'Lingala',
                'lo_LA'  =>  'Lao',
                'lt_LT'  =>  'Lithuanian',
                'lv_LV'  =>  'Latvian',
                'mg_MG'  =>  'Malagasy',
                'mk_MK'  =>  'Macedonian',
                'ml_IN'  =>  'Malayalam',
                'mn_MN'  =>  'Mongolian',
                'mr_IN'  =>  'Marathi',
                'ms_MY'  =>  'Malay',
                'mt_MT'  =>  'Maltese',
                'my_MM'  =>  'Burmese',
                'nb_NO'  =>  'Norwegian (bokmal)',
                'nd_ZW'  =>  'Ndebele',
                'ne_NP'  =>  'Nepali',
                'nl_BE'  =>  'Dutch (België)',
                'nl_NL'  =>  'Dutch',
                'nn_NO'  =>  'Norwegian (nynorsk)',
                'ny_MW'  =>  'Chewa',
                'or_IN'  =>  'Oriya',
                'pa_IN'  =>  'Punjabi',
                'pl_PL'  =>  'Polish',
                'ps_AF'  =>  'Pashto',
                'pt_BR'  =>  'Portuguese (Brazil)',
                'pt_PT'  =>  'Portuguese (Portugal)',
                'qu_PE'  =>  'Quechua',
                'rm_CH'  =>  'Romansh',
                'ro_RO'  =>  'Romanian',
                'ru_RU'  =>  'Russian',
                'rw_RW'  =>  'Kinyarwanda',
                'sa_IN'  =>  'Sanskrit',
                'sc_IT'  =>  'Sardinian',
                'se_NO'  =>  'Northern Sámi',
                'si_LK'  =>  'Sinhala',
                'sk_SK'  =>  'Slovak',
                'sl_SI'  =>  'Slovenian',
                'sn_ZW'  =>  'Shona',
                'so_SO'  =>  'Somali',
                'sq_AL'  =>  'Albanian',
                'sr_RS'  =>  'Serbian',
                'sv_SE'  =>  'Swedish',
                'sw_KE'  =>  'Swahili',
                'sy_SY'  =>  'Syriac',
                'sz_PL'  =>  'Silesian',
                'ta_IN'  =>  'Tamil',
                'te_IN'  =>  'Telugu',
                'tg_TJ'  =>  'Tajik',
                'th_TH'  =>  'Thai',
                'tk_TM'  =>  'Turkmen',
                'tl_PH'  =>  'Filipino',
                'tl_ST'  =>  'Klingon',
                'tr_TR'  =>  'Turkish',
                'tt_RU'  =>  'Tatar',
                'tz_MA'  =>  'Tamazight',
                'uk_UA'  =>  'Ukrainian',
                'ur_PK'  =>  'Urdu',
                'uz_UZ'  =>  'Uzbek',
                'vi_VN'  =>  'Vietnamese',
                'wo_SN'  =>  'Wolof',
                'xh_ZA'  =>  'Xhosa',
                'yi_DE'  =>  'Yiddish',
                'yo_NG'  =>  'Yoruba',
                'zh_CN'  =>  'Simplified Chinese (China)',
                'zh_HK'  =>  'Traditional Chinese (Hong Kong)',
                'zh_TW'  =>  'Traditional Chinese (Taiwan)',
                'zu_ZA'  =>  'Zulu',
                'zz_TR'  =>  'Zazaki',
            );
        }

        $fields[] = array(
            'name'      =>  __( 'Comment Texts', 'better-studio' ),
            'type'      => 'group',
            'state'     => 'close',
        );
        $fields['text_no_comment'] = array(
            'name'          =>  __( 'No Comment Text', 'better-studio' ),
            'id'            =>  'text_no_comment',
            'type'          =>  'text',
            'std'           =>  'No Comment',
        );
        $fields['text_one_comment'] = array(
            'name'          =>  __( 'One Comment Text', 'better-studio' ),
            'id'            =>  'text_one_comment',
            'type'          =>  'text',
            'std'           =>  'One Comment',
        );
        $fields['text_two_comment'] = array(
            'name'          =>  __( 'Two Comment Text', 'better-studio' ),
            'id'            =>  'text_two_comment',
            'type'          =>  'text',
            'std'           =>  'Two Comment',
        );
        $fields['text_comments'] = array(
            'name'          =>  __( 'Comments Text', 'better-studio' ),
            'id'            =>  'text_comments',
            'type'          =>  'text',
            'std'           =>  '%%NUMBER%% Comment',
        );

        // Language  name for smart admin texts
        $lang = bf_get_current_lang_raw();
        if( $lang != 'none' ){
            $lang = bf_get_language_name( $lang );
        }else{
            $lang = '';
        }

        $options[self::$panel_id] = array(
            'config' => array(
                'parent'                =>  'better-studio',
                'slug' 			        =>  'better-studio/better-facebook-comments',
                'name'                  =>  __( 'Better Facebook Comments', 'better-studio' ),
                'page_title'            =>  __( 'Better Facebook Comments', 'better-studio' ),
                'menu_title'            =>  __( 'Facebook Comments', 'better-studio' ),
                'capability'            =>  'manage_options',
                'icon_url'              =>  null,
                'position'              =>  80.08,
                'exclude_from_export'   =>  false,
            ),
            'texts'         =>  array(

                'panel-desc-lang'       =>  '<p>' . __( '%s Language Options.', 'better-studio' ) . '</p>',
                'panel-desc-lang-all'   =>  '<p>' . __( 'All Languages Options.', 'better-studio' ) . '</p>',

                'reset-button'      => ! empty( $lang ) ? sprintf( __( 'Reset %s Options', 'better-studio' ), $lang ) : __( 'Reset Options', 'better-studio' ),
                'reset-button-all'  => __( 'Reset All Options', 'better-studio' ),

                'reset-confirm'     =>  ! empty( $lang ) ? sprintf( __( 'Are you sure to reset %s options?', 'better-studio' ), $lang ) : __( 'Are you sure to reset options?', 'better-studio' ),
                'reset-confirm-all' => __( 'Are you sure to reset all options?', 'better-studio' ),

                'save-button'       =>  ! empty( $lang ) ? sprintf( __( 'Save %s Options', 'better-studio' ), $lang ) : __( 'Save Options', 'better-studio' ),
                'save-button-all'   =>  __( 'Save All Options', 'better-studio' ),

                'save-confirm-all'  =>  __( 'Are you sure to save all options? this will override specified options per languages', 'better-studio' )

            ),
            'panel-name'        => _x( 'Better Facebook Comments', 'Panel title', 'better-studio' ),
            'panel-desc'        =>  '<p>' . __( 'Take advantage of integrating Facebook comments on your website.', 'better-studio' ) . '</p>',
            'fields'            => $fields
        );

        return $options;
    }


    /**
     * Finds appropriate template file and return path
     * This make option to change template in themes
     *
     * @return string
     */
    function get_template(){

        // Use theme specified template for search page
        if( file_exists( get_template_directory() . '/better-facebook-comments.php' ) ){
            return get_template_directory() . '/better-facebook-comments.php';
        }

        return $this->dir_path( 'templates/better-facebook-comments.php' );

    }


    /**
     * Changes WP comments template with Facebook template
     *
     * @return string
     */
    function custom_comments_template(){

        return $this->get_template();

    }


    /**
     * Callback: Used to clear themes meta text to better style in front-end
     *
     * Filter: better-studio/themes/meta/comments/text
     *
     * @param $text
     *
     * @return string
     */
    function better_studio_themes_comment_text( $text ) {

        return '';

    }


    /**
     * Callback: Used to change themes meta link to support Facebook count
     *
     * Filter: better-studio/themes/meta/comments/link
     *
     * @param $link
     *
     * @return string
     */
    function better_studio_themes_comment_link( $link ) {

        return get_permalink() . '#facebook_thread';

    }


    /**
     * Callback: Adds Facebook App data to header
     *
     * Action: wp_head
     */
    function wp_head(){

        echo '<meta property="fb:app_id" content="' . $this->get_option( 'app_id' ) . '">';

    }
}
