<?php
/*
Plugin Name: Better Google Custom Search
Plugin URI: http://betterstudio.com
Description: Replace the default WordPress search engine with search powered by Google.
Version: 1.0.0
Author: BetterStudio
Author URI: http://betterstudio.com
License: GPL2
*/


/**
 * Better_GCS class wrapper for make changes safe in future
 *
 * @return Better_GCS
 */
function Better_GCS(){
    return Better_GCS::self();
}


// Initialize Better Google Custom Search
Better_GCS();


/**
 * Handy function used for generating search box to page
 *
 * this make usability easy and safe for feature changes
 */
function Better_GCS_Search_Box(){
    Better_GCS()->generate_search_box();
}


/**
 * Class Better_GCS
 */
class Better_GCS{


    /**
     * Contains Better_GCS version number that used for assets for preventing cache mechanism
     *
     * @var string
     */
    private static $version = '1.0.0';


    /**
     * Contains Better_GCS option panel id
     *
     * @var string
     */
    private static $panel_id = 'better_google_custom_search';


    /**
     * Inner array of instances
     *
     * @var array
     */
    protected static $instances = array();


    function __construct(){

        // Admin panel options
        add_filter( 'better-framework/panel/options' , array( $this , 'setup_option_panel' ) );

        // Initialize
        add_action( 'better-framework/after_setup', array( $this, 'init' ) );

        // Enqueue assets
        add_action( 'wp_enqueue_scripts', array($this, 'enqueue_assets') );

        // Callback for changing search page template
        add_action( 'template_redirect', array( $this, 'show_search_box' ) );

    }


    /**
     * Used for accessing plugin directory URL
     *
     * @param string $address
     *
     * @return string
     */
    public static function dir_url( $address = '' ){

        return plugin_dir_url( __FILE__ ) . $address;

    }


    /**
     * Used for accessing plugin directory path
     *
     * @param string $address
     *
     * @return string
     */
    public static function dir_path( $address = '' ){

        return plugin_dir_path( __FILE__ ) . $address;

    }


    /**
     * Returns BSC current Version
     *
     * @return string
     */
    public static function get_version(){

        return self::$version ;

    }


    /**
     * Build the required object instance
     *
     * @param string $object
     * @param bool $fresh
     * @param bool $just_include
     * @return null
     */
    public static function factory( $object = 'self', $fresh = false , $just_include = false ){

        if( isset( self::$instances[$object] ) && ! $fresh ){
            return self::$instances[$object];
        }

        switch( $object ){

            /**
             * Main Better_GCS Class
             */
            case 'self':
                $class = 'Better_GCS';
                break;

            default:
                return null;
        }


        // Just prepare/includes files
        if( $just_include )
            return;

        // don't cache fresh objects
        if( $fresh ){
            return new $class;
        }

        self::$instances[$object] = new $class;

        return self::$instances[$object];
    }


    /**
     * Used for accessing alive instance of Better_GCS
     *
     * static
     * @since 1.0
     * @return Better_GCS
     */
    public static function self(){

        return self::factory();

    }


    /**
     * Used for retrieving options simply and safely for next versions
     *
     * @param $option_key
     * @return mixed|null
     */
    public static function get_option( $option_key ){

        return bf_get_option( $option_key, self::$panel_id );

    }


    /**
     *  Init the plugin
     */
    function init(){

        load_plugin_textdomain( 'better-studio', false, 'better-google-custom-search/languages' );

    }


    /**
     * Enqueue css and js files
     */
    function enqueue_assets(){

        // Enqueue scripts only if this is search page and engine id is valid
        if( BF()->helper()->is_search_page() && $this->get_engine_id() ){

            wp_enqueue_script( 'google-json-api', '//www.google.com/jsapi', array(), $this->get_version(), true );

            wp_enqueue_style( 'better-google-custom-search', $this->dir_url( 'css/better-google-custom-search.css' ) , array(), $this->get_version() );

        }

    }


    /**
     * Callback: Used to change search page with Google Custom Search
     *
     * Action: template_redirect
     */
    function show_search_box(){

        // don't do anything when it's not search page
        if( ! BF()->helper()->is_search_page() ){
            return;
        }

        // If engine id isn't defined
        if( ! $this->get_engine_id() )
            return;

        include $this->get_template();

        exit;

    }


    /**
     * Finds appropriate template file and return path
     * This make option to change template in themes
     *
     * @return string
     */
    function get_template(){

        // Use theme specified template for search page
        if( file_exists( get_template_directory() . '/better-gcs.php' ) ){
            return get_template_directory() . '/better-gcs.php';
        }

        return $this->dir_path() . 'templates/better-gcs.php';

    }


    /**
     * Generate search result box
     */
    function generate_search_box(){

        // Set style/theme
        $theme = 'style : google.loader.themes.' . $this->get_option( 'search_theme' );

        // Run google search by query
        if( isset( $_REQUEST['s'] ) && '' != $_REQUEST['s'] )
            $search_query = 'customSearchControl.execute("' . $_REQUEST['s'] . '");';
        else
            $search_query = '';

        $box_id = "cgs-search-form";

        // Show search button
        if( $this->get_option( 'show_search_button' ) ){
            $show_button = 'show-search-button';
        }
        else{
            $show_button = 'hide-search-button';
        }

        // Add Init JS to Footer
        BF()->assets_manager()->add_js( "\n/* Better Google Custom Search Scripts */" . '
google.load( "search", "1", {language : "'. get_locale() . '" ,' . $theme . '} );
google.setOnLoadCallback( function() {
    var customSearchControl = new google.search.CustomSearchControl( "' . $this->get_engine_id() . '" );
    var options = new google.search.DrawOptions();
    options.setSearchFormRoot("' . $box_id . '");
    options.setAutoComplete(true);
    customSearchControl.setResultSetSize( google.search.Search.FILTERED_CSE_RESULTSET );
    customSearchControl.draw( "cgs-' . $box_id . '", options );
    ' . $search_query .'
}, true );' . "\n/* /Better Google Custom Search Scripts */\n"
            , false );

        // Input and Result Tags
        echo '
        <!-- Better Google Custom Search Result Box -->
        <div id="' . $box_id . '" class="better-gcs-input ' . $show_button . ' ' . $this->get_option( 'search_theme' ) . '">' . $this->get_option( 'loading_text' ) . '</div>
        <div id="cgs-' . $box_id . '" class="better-gcs-result ' . $this->get_option( 'search_theme' ) . '"></div>
        <!-- Better Google Custom Search Result Box -->
        ';
    }


    /**
     * Return google search engine id
     *
     * @return mixed|string
     */
    function get_engine_id(){

        // Remove extra characters
        $embed_code = preg_replace( "/[ \n\r\t\v\'\"]/m", '', stripslashes( $this->get_option( 'engine_id' ) ) );

        // Start position of engine ID
        $start = strpos( $embed_code, 'varcx=' );

        // End position of engine ID
        $end = strpos( $embed_code, ';', $start );

        // It's a valid Code
        if( $start && $end ){

            // cut code and get id from that
            $engine_id = substr( $embed_code, $start + 6, $end - ( $start + 6 ) );

        }
        // It's a ID
        else{
            $engine_id = $embed_code;
        }

        return $engine_id;
    }


    /**
     * Setup setting panel
     *
     * @param $options
     * @return array
     */
    function setup_option_panel( $options ){

        $field[] = array(
            'name'          =>  __( 'How To Setup', 'better-studio' ),
            'id'       =>  'google-custom-search-help',
            'type'          =>  'info',
            'std'           =>  __('<ol>
<li>Go to <a href="http://goo.gl/Pw8qFw" target="_blank">Google Custom Search Engine</a> Page</li>
<li>Click <strong>Create a custom search engine</strong> button</li>
<li>In next page fill <strong>Sites to search</strong> input with your site address and click <strong>CREATE</strong> button</li>
<li>In next page click <strong>Get code</strong> button and copy code in opened page</li>
<li>Paste code into following <strong>Embed Code/Search ID</strong> input.</li>
</ol>', 'better-studio' ),
            'state'         =>  'open',
            'info-type'     =>  'help',
            'section_class' =>  'widefat',
        );
        $field['engine_id'] = array(
            'name'      =>  __( 'Embed Code/Search ID', 'better-studio' ),
            'id'        =>  'engine_id',
            'desc'      =>  __( 'Paste the Custom Search embed code or Search engine unique ID here. <br><br>Note that any customized styles will be stripped out.', 'better-studio' ),
            'type'      =>  'textarea',
            'std'       =>  ''
        );
        $field['search_theme'] = array(
            'name'      =>  __( 'Theme/Style', 'better-studio' ),
            'id'        =>  'search_theme',
            'std'       =>  'CLASSIC',
            'type'      =>  'image_select',
            'list_style'      =>  'grid-3-column',
            'desc'      =>  __( 'Select color scheme for the search box.', 'better-studio' ),
            'section_class' => 'style-floated-left bordered',
            'options' => array(
                'CLASSIC'    =>  array(
                    'img'   =>  $this->dir_url() . 'img/theme-classic.png',
                    'label' =>  __( 'Classic', 'better-studio' ),
                ),
                'MINIMALIST'    =>  array(
                    'img'   =>  $this->dir_url() . 'img/theme-minimalist.png',
                    'label' =>  __( 'Minimalist', 'better-studio' ),
                ),
                'ESPRESSO'    =>  array(
                    'img'   =>  $this->dir_url() . 'img/theme-espresso.png',
                    'label' =>  __( 'Espresso', 'better-studio' ),
                ),
                'GREENSKY'    =>  array(
                    'img'   =>  $this->dir_url() . 'img/theme-greensky.png',
                    'label' =>  __( 'Green Sky', 'better-studio' ),
                ),
                'BUBBLEGUM'    =>  array(
                    'img'   =>  $this->dir_url() . 'img/theme-bubblegum.png',
                    'label' =>  __( 'Bubble Gum', 'better-studio' ),
                ),
                'SHINY'    =>  array(
                    'img'   =>  $this->dir_url() . 'img/theme-shiny.png',
                    'label' =>  __( 'Shiny', 'better-studio' ),
                ),
            )
        );
        $field[] = array(
            'name'      =>  __('Display Search Button','better-studio'),
            'id'        =>  'show_search_button',
            'std'       =>  '1' ,
            'type'      =>  'switch',
            'on-label'  =>  __( 'Show', 'better-studio' ),
            'off-label' =>  __( 'Hide', 'better-studio' ),
        );
        $field['loading_text'] = array(
            'name'      =>  __( 'Loading Text', 'better-studio' ),
            'id'        =>  'loading_text',
            'type'      =>  'text',
            'std'       =>  __( 'Loading...', 'better-studio' )
        );

        // Language  name for smart admin texts
        $lang = bf_get_current_lang();
        if( $lang != 'none' ){
            $lang = bf_get_language_name();
        }else{
            $lang = '';
        }

        $options[self::$panel_id] = array(
            'config' => array(
                'parent'                =>  'better-studio',
                'slug' 			        =>  'better-studio/better-google-custom-search',
                'name'                  =>  __( 'Google Custom Search', 'better-studio' ),
                'page_title'            =>  __( 'Google Custom Search', 'better-studio' ),
                'menu_title'            =>  __( 'Google Search', 'better-studio' ),
                'capability'            =>  'manage_options',
                'icon_url'              =>  null,
                'position'              =>  80.09,
                'exclude_from_export'   =>  false,
            ),
            'texts'         =>  array(

                'panel-desc-lang'       =>  '<p>' . __( '%s Language Options.', 'better-studio' ) . '</p>',
                'panel-desc-lang-all'   =>  '<p>' . __( 'All Languages Options.', 'better-studio' ) . '</p>',

                'reset-button'      => ! empty( $lang ) ? sprintf( __( 'Reset %s Options', 'better-studio' ), $lang ) : __( 'Reset Options', 'better-studio' ),
                'reset-button-all'  => __( 'Reset All Options', 'better-studio' ),

                'reset-confirm'     =>  ! empty( $lang ) ? sprintf( __( 'Are you sure to reset %s options?', 'better-studio' ), $lang ) : __( 'Are you sure to reset options?', 'better-studio' ),
                'reset-confirm-all' => __( 'Are you sure to reset all options?', 'better-studio' ),

                'save-button'       =>  ! empty( $lang ) ? sprintf( __( 'Save %s Options', 'better-studio' ), $lang ) : __( 'Save Options', 'better-studio' ),
                'save-button-all'   =>  __( 'Save All Options', 'better-studio' ),

                'save-confirm-all'  =>  __( 'Are you sure to save all options? this will override specified options per languages', 'better-studio' )

            ),
            'panel-name'        => _x( 'Better Google Custom Search', 'Panel title', 'better-studio' ),
            'panel-desc'        =>  '<p>' . __( 'Replace the default WordPress search engine with search powered by Google.', 'better-studio' ) . '</p>',
            'fields'            => $field
        );

        return $options;
    }
}
